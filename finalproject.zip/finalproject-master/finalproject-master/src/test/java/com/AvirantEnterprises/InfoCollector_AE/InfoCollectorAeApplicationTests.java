package com.AvirantEnterprises.InfoCollector_AE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoCollectorAeApplicationTests {

	@Test
	void contextLoads() {
	}

}
