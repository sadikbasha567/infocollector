package com.AvirantEnterprises.InfoCollector_AE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfoCollectorAeApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfoCollectorAeApplication.class, args);
	}

}
